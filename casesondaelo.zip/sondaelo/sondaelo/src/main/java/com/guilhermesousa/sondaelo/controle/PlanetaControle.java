package com.guilhermesousa.sondaelo.controle;

import com.guilhermesousa.sondaelo.entidade.Planeta;
import com.guilhermesousa.sondaelo.repositorio.PlanetaRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/planetas")
public class PlanetaControle {

    @Autowired
    private PlanetaRepositorio planetaRepositorio;

    // Endpoint para criar um planeta
    @PostMapping
    public ResponseEntity criaPlaneta(@RequestBody Planeta novoPlaneta){

            this.planetaRepositorio.save(novoPlaneta);
            return ResponseEntity.status(201).build();
    }

    //Endpoint para obter todos planetas criados
    @GetMapping
    public ResponseEntity obterTodosPlanetas(){
        List<Planeta> planetas = this.planetaRepositorio.findAll();
        if(planetas.size() > 0){

            return ResponseEntity.status(200).body(planetas);
        }
        else {
            return ResponseEntity.status(204).build();
        }
    }

    // Endpoint para obter um planeta especifico
    @GetMapping("/{id}")
    public ResponseEntity obterPlaneta(@PathVariable int id){
        Optional<Planeta> planeta = this.planetaRepositorio.findById(id);
        if(planeta.isPresent()){

            return ResponseEntity.status(200).body(planeta);
        }
        else {
            return ResponseEntity.status(404).build();
        }
    }

    // Altera informações de um planeta especifico
    @PutMapping("/{id}")
    public ResponseEntity alterarPlaneta(@RequestBody Planeta planeta,
                                         @PathVariable int id){
        if(this.planetaRepositorio.existsById(id)){
            planeta.setId(id);
            this.planetaRepositorio.save(planeta);

            return ResponseEntity.status(200).build();
        }
        else {
            return ResponseEntity.status(404).build();
        }
    }

    // Deleta um planeta especifico
    @DeleteMapping("/{id}")
    public ResponseEntity deletarPlaneta(@PathVariable int id){
        if(this.planetaRepositorio.existsById(id)){
            this.planetaRepositorio.deleteById(id);
            return ResponseEntity.status(200).build();
        } else {
            return ResponseEntity.status(404).build();
        }
    }

}
