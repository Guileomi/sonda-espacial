package com.guilhermesousa.sondaelo.repositorio;

import com.guilhermesousa.sondaelo.entidade.Planeta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlanetaRepositorio extends JpaRepository<Planeta, Integer> {
}
