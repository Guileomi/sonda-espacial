package com.guilhermesousa.sondaelo.repositorio;

import com.guilhermesousa.sondaelo.entidade.Sonda;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SondaRepositorio extends JpaRepository<Sonda, Integer> {

}
