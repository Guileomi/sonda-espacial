package com.guilhermesousa.sondaelo.entidade;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Arrays;

@Entity
public class Sonda {

    // Identificação da sonda
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idSonda")
    private int id;

    //Posicao "x" da Sonda
    @Column(name = "posicaoSondaX", length = 2)
    private int posicaoSondaX;

    //Posicao "y" da Sonda
    @Column(name = "posicaoSondaY", length = 2)
    private int posicaoSondaY;

    //Direção que a sonda se encontra
    @Column(name = "direcaoSonda", length = 1)
    private String direcaoSonda;

    //Planeta que a sonda está
    @ManyToOne
    @JoinColumn(name = "idPlaneta")
    private Planeta planeta;

    ///Criados para guiar o usuario enquanto utiliza a lógica de movimentação e de pouso
    @Transient
    private boolean ladoDireito = false;

    @Transient
    private boolean ladoEsquerdo = false;

    //Transient porque não será necessário seu save no banco de dados
    @Transient
    private ArrayList<String> pontosCardeais = new ArrayList<String>(Arrays.asList("N", "L", "S", "O"));

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPosicaoSondaX() {
        return posicaoSondaX;
    }

    public void setPosicaoSondaX(int posicaoSondaX) {
        this.posicaoSondaX = posicaoSondaX;
    }

    public int getPosicaoSondaY() {
        return posicaoSondaY;
    }

    public void setPosicaoSondaY(int posicaoSondaY) {
        this.posicaoSondaY = posicaoSondaY;
    }

    public String getDirecaoSonda() {
        return direcaoSonda;
    }

    public void setDirecaoSonda(String direcaoSonda) {
        this.direcaoSonda = direcaoSonda;
    }

    public Planeta getPlaneta() {
        return planeta;
    }

    public void setPlaneta(Planeta planeta) {
        this.planeta = planeta;
    }

    public boolean isLadoDireito() {
        return ladoDireito;
    }

    public void setLadoDireito(boolean ladoDireito) {
        this.ladoDireito = ladoDireito;
    }

    public boolean isLadoEsquerdo() {
        return ladoEsquerdo;
    }

    public void setLadoEsquerdo(boolean ladoEsquerdo) {
        this.ladoEsquerdo = ladoEsquerdo;
    }

    // Método para movimentar a sonda de acordo com a sua direção
    public void moverSonda(){
        if(this.direcaoSonda.equals("N") && this.posicaoSondaY < this.planeta.getPosicaoPlanetaY()){
            this.posicaoSondaY++;
        }
        else if(this.direcaoSonda.equals("S") && this.posicaoSondaY > 0){
            this.posicaoSondaY--;
        }
        else if(this.direcaoSonda.equals("L") && this.posicaoSondaX < this.planeta.getPosicaoPlanetaX()){
            this.posicaoSondaX++;
        }
        else if(this.direcaoSonda.equals("O") && this.posicaoSondaX > 0){
            this.posicaoSondaX--;
        }
        else {
            System.out.println("Impossibilidade de movimentação");
        }
    }

    // Método para virar a sonda a direita utilizando o ArrayList "pontosCardeais"
    public void virarADireita() {
        int posicaoSonda =  pontosCardeais.indexOf(direcaoSonda);
        if(posicaoSonda == 3) {
            direcaoSonda = pontosCardeais.get(0);
        }
        else {
            direcaoSonda = pontosCardeais.get(posicaoSonda+1);
        }
    }

    // Método para virar a sonda a esquerda utilizando o ArrayList "pontosCardeais"
    public void virarAEsquerda(){
        int posicaoSonda =  pontosCardeais.indexOf(direcaoSonda);
        if(posicaoSonda == 0){
            direcaoSonda = pontosCardeais.get(3);
        }else{
            direcaoSonda = pontosCardeais.get(posicaoSonda-1);
        }
    }
}
