package com.guilhermesousa.sondaelo.controle;

import com.guilhermesousa.sondaelo.entidade.Planeta;
import com.guilhermesousa.sondaelo.entidade.Sonda;
import com.guilhermesousa.sondaelo.repositorio.PlanetaRepositorio;
import com.guilhermesousa.sondaelo.repositorio.SondaRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/sondas")
public class SondaControle {

    @Autowired
    private SondaRepositorio sondaRepositorio;

    @Autowired
    private PlanetaRepositorio planetaRepositorio;

    //Endpoint para criar uma sonda
    @PostMapping
    public ResponseEntity criaSonda(@RequestBody Sonda novaSonda){
        Optional<Planeta> planeta = this.planetaRepositorio.findById(novaSonda.getPlaneta().getId());
        if(!planeta.isPresent()){
            return ResponseEntity.status(400).build();
        }
        if((novaSonda.getPosicaoSondaX() > planeta.get().getPosicaoPlanetaX() || novaSonda.getPosicaoSondaX() < 0)
            || (novaSonda.getPosicaoSondaY() > planeta.get().getPosicaoPlanetaY() || novaSonda.getPosicaoSondaY() <= 0)){

            return ResponseEntity.status(400).body("Sonda não condizente com posições Y OU X do planeta. ");
        }
        else {
            List<Sonda> sondas = this.sondaRepositorio.findAll();
            for (Sonda s : sondas){
                if((s.getPosicaoSondaX() == novaSonda.getPosicaoSondaX()) && (s.getPosicaoSondaY() == novaSonda.getPosicaoSondaY())){

                    return ResponseEntity.status(400).body("Tentativa de criação de sonda impossibilitada pois a mesma possui as mesmas posições de outra já criada.");
                }
            }
            this.sondaRepositorio.save(novaSonda);

            return ResponseEntity.status(201).build();
        }
    }

    // Endpoint para obter todas as sondas criadas
    @GetMapping
    public ResponseEntity obterTodasSondas(){
        List<Sonda> sondas = this.sondaRepositorio.findAll();
        if (sondas.size() > 0){

            return ResponseEntity.status(200).body(sondas);
        }
        else{
            return ResponseEntity.status(204).build();
        }
    }

    // Endpoint para obter uma sonda especifica
    @GetMapping("/{id}")
    public ResponseEntity obterSonda(@PathVariable int id){
        Optional<Sonda> sonda = this.sondaRepositorio.findById(id);
        if(sonda.isPresent()){

            return ResponseEntity.status(200).body(sonda);
        }
        else {
            return ResponseEntity.status(404).build();
        }
    }

    // Endpoint para deletar uma sonda
    @DeleteMapping("/{id}")
    public ResponseEntity deletarSonda(@PathVariable int id){
        if(this.sondaRepositorio.existsById(id)){
            this.sondaRepositorio.deleteById(id);

            return ResponseEntity.status(200).build();
        }
        else {
            return ResponseEntity.status(404).build();
        }
    }

    //Endpoint para mover a sonda
    @PutMapping("/{idSonda}/{comandos}")
    public ResponseEntity moverSonda(@PathVariable("idSonda") int idSonda,
                                     @PathVariable("comandos") String comandos){
        Optional<Sonda> sonda = sondaRepositorio.findById(idSonda);
        List<Sonda> sondas = sondaRepositorio.findAll();
        if(sondaRepositorio.existsById(idSonda)) {
            for (char comando : comandos.toCharArray()) {
                switch (comando) {
                    case 'E':
                        sonda.get().virarAEsquerda();
                        sonda.get().setLadoEsquerdo(true);
                        sonda.get().setLadoDireito(false);
                        this.sondaRepositorio.save(sonda.get());
                        break;

                    case 'D':
                        sonda.get().virarADireita();
                        sonda.get().setLadoDireito(true);
                        sonda.get().setLadoEsquerdo(false);
                        this.sondaRepositorio.save(sonda.get());
                        break;

                    case 'M':
                        sonda.get().moverSonda();
                        for (Sonda p : sondas) {

                            if (((sonda.get().getPosicaoSondaY() == p.getPosicaoSondaY())
                                    && (sonda.get().getPosicaoSondaX() == p.getPosicaoSondaX())) && !p.equals(sonda.get())) {
                                System.out.println("CUIDADO! Está se direcionando a mesma posição de outra sonda! Assumindo comando e girando em 360 graus.");
                                sonda.get().virarADireita();
                                sonda.get().virarADireita();
                                sonda.get().moverSonda();
                                sonda.get().virarADireita();
                                sonda.get().virarADireita();

                            }
                        }
                        this.sondaRepositorio.save(sonda.get());
                        break;

                    default:
                        System.out.println("Erro ao se movimentar: Comandos permitidos: E (Esquerda), D (Direita e M (Mover)!");
                }
            }
            return ResponseEntity.status(200).body(sonda.get());
        }
            else {
            return ResponseEntity.status(404).build();
        }
    }
}
