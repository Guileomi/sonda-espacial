package com.guilhermesousa.sondaelo.entidade;

import javax.persistence.*;

@Entity
public class Planeta {

    // Identificação do planeta
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idPlaneta")
    private Integer id;

    //Nome do planeta
    @Column(name = "nomePlaneta",length = 30, nullable = false, unique = true)
    private String nome;

    //Posição "x" do planeta
    @Column(length = 1, nullable = false)
    private Integer posicaoPlanetaX;

    //Posição "y" do planeta
    @Column(length = 1, nullable = false)
    private Integer posicaoPlanetaY;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getPosicaoPlanetaX() {
        return posicaoPlanetaX;
    }

    public void setPosicaoPlanetaX(Integer posicaoPlanetaX) {
        this.posicaoPlanetaX = posicaoPlanetaX;
    }

    public Integer getPosicaoPlanetaY() {
        return posicaoPlanetaY;
    }

    public void setPosicaoPlanetaY(Integer posicaoPlanetaY) {
        this.posicaoPlanetaY = posicaoPlanetaY;
    }
}
