package com.guilhermesousa.sondaelo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SondaeloApplicationTests {

	@Test
	void contextLoads() {
	}

}
