package com.guilhermesousa.sondaelo.controle;

import com.guilhermesousa.sondaelo.repositorio.PlanetaRepositorio;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

@SpringBootTest
public class PlanetaControleTest {

    @Autowired
    PlanetaControle controle;

    @MockBean
    PlanetaRepositorio repositorio;

    /*
    @Test
    void semSondasDeveRetornar204(){
        when(repositorio.findAll()).thenReturn(new ArrayList<>());

        ResponseEntity resposta = controle.obterTodosPlanetas();

        assertEquals(204, resposta.getStatusCodeValue());
        assertNull(resposta.getBody());
    }

    @Test
    void comSondasDeveRetornar200(){
        when(repositorio.findAll()).thenReturn(new ArrayList<>());

        ResponseEntity resposta = controle.obterTodosPlanetas();

        assertEquals(200, resposta.getStatusCodeValue());
        assertNull(resposta.getBody());
    }
    */
}
